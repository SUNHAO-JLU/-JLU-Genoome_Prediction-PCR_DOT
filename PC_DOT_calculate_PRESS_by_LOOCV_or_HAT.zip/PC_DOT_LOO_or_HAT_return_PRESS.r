###############################################################################################
###############################################################################################
## refX dimensionality: n*m ;  n denotes sample size; m denotes variables (SNPs)
given_refX_get_pc_D_v=function(refX){
                                      X=refX
									  sample_size=nrow(X)
									  
                                      e=eigen(X%*%t(X))
                                      pc=e$vectors[,-sample_size]%*%(diag(sqrt(e$values[-sample_size])))
                                      
									  #pc[1:3,1:3]                                      
									  D=e$values[-sample_size]                                      
									  V=t(X)%*%e$vectors[,-sample_size]%*%diag(sqrt(1/D))
return(list(pc,
            D,
			V
            ))
}

###############################################################################################
###############################################################################################
## LOO cross-validation
LOO_hat_PDP=function(pc,D,ry){                           
						      						   
						        solve_d=diag(1/D,length(D),length(D))
						              H=pc%*%solve_d%*%t(pc)						   
						          error=H%*%ry-ry						  					 
                                  press=(error/(1-diag(H)))^2
                                  PRESS=sum(press)
					        
							    return(PRESS)
                            }

## LOO cross-validation
LOO_CV=function(pc,ry){                           
                        pre_y=NULL					  
 						    							
							for(i in 1:length(ry)){
							
							                       testry=ry[i]
                                                      rry=ry[-i]
                                                   testrx=pc[i,]
                                                      rrx=pc[-i,]

                                                     bata=summary(lm(rry~rrx))$coefficients[,1]							 
							                     pre_y[i]=bata[1]+testrx%*%as.matrix(bata[-1])	
							}	
							
						PRESS=sum((ry-pre_y)^2)
							
						return(PRESS)
					} 						   
						      
							  
							  
###############################################################################################
###############################################################################################
##  provide rx ry, return the best PCs and model
PCR_HAT_or_LOO_dot_input_rx_ry_return_PRESS=function(rx,ry){

    eigen.rx=given_refX_get_pc_D_v(rx)
    
	pc.rx=eigen.rx[[1]]
	D.rx=eigen.rx[[2]]
	V.rx=eigen.rx[[3]]
	
	
	rx=pc.rx


##  0.90 variance
##	
rxv=apply(rx,2,var)
	
	for(i in 1: ncol(rx) ){ vv=sum(rxv[1:i])/sum(rxv)
                            if(0.90<= vv ){break}
    					  }
	print(i) ## the max PC numbers
	v90=i
	
	rx=rx[,1:v90]


##  PCR_dot	
##	     	
dot_product_square=apply(rx,2,function(ppp){ (sum(ppp*ry))^2  }    )	   
				
##  rank: dot product square 	 
##	     	
rankrfx=rank(-dot_product_square)
   
	   
##  the best PCs	 
##	   	   
press_HAT=NULL 
press_LOO=NULL


    for(i in 2:ncol(rx)){
                         pos=which(rankrfx<=i)
						 
                         press_HAT[i]=LOO_hat_PDP(rx[,pos],D.rx[pos],ry)
	                     press_LOO[i]=LOO_CV(rx[,pos],ry)
						
					
						}
						
	    
return(list(            
            press_HAT,
			press_LOO
		    ))
}





###########################################################	
###########################################################
### sim data
y <- read.table(file="sim.y.txt",header=FALSE)                    
sample_size=length(y)
y=as.matrix(y)
gen <- read.csv(file="sim.x.csv",header=TRUE)
G=as.matrix(t(gen))
G[G==1]=2
G[G==0]=1
G[G==-1]=0
X=apply(G,2,function(ggg){ f=mean(ggg)/2
                           (ggg-f*2)/sqrt(2*f*(1-f))
                         })
###########################################################
result=PCR_HAT_or_LOO_dot_input_rx_ry(X,y)
HAT=result[[1]]
LOO=result[[2]]
which.min(HAT)
which.min(LOO)
cor(HAT[-1],LOO[-1],method="spearman")




###########################################################	
###########################################################
### rice data
phe <- read.csv(file="RIL.phenew.scale.txt",header=TRUE)                    
yused=2
y<-as.matrix(phe[,yused]) 
gen <- read.csv(file="RIL.gen.txt",header=TRUE)
dim(gen)
z <- as.matrix(t(gen))
z <- scale(z)
x <- z
###########################################################
result=PCR_HAT_or_LOO_dot_input_rx_ry_return_PRESS(x,y)
HAT=result[[1]]
LOO=result[[2]]
which.min(HAT)
which.min(LOO)
cor(HAT[-1],LOO[-1],method="spearman")